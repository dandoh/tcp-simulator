package state;

import Fsm.State;

public class StartState extends State {

	public StartState(String name) {
		super(name);
	}

}
