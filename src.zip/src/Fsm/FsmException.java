//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package Fsm;

public class FsmException extends Exception {

	FsmException(String e) {
        super(e);
    }
}
